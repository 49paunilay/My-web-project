//This function is used to open the sidebar//
function opennav(){
    document.getElementById("sidebar").style.width="250px";
    document.getElementById("main").style.marginLeft="250px";
    document.body.style.background = "rgba(0,0,0,0,4)";
}
//This function is used to close the sidebar//
function closenav(){
    document.getElementById("sidebar").style.width="0px";
    document.getElementById("main").style.marginLeft="0px";
    document.body.style.background="white";
}
//This function checks for street ,firstname,lastname according to the true or false we assign color and string//
function check(){
    var street= document.getElementById("street").value;
    var firstname = document.getElementById("fname").value;
    var lastname = document.getElementById("lname").value;
    
    if(firstname.length<2){
        document.getElementById("fnameid").innerHTML="Please enter your name";
        document.getElementById("fnameid").style.color="red";
    }
    else{
        document.getElementById("fnameid").innerHTML="Accepted";
        document.getElementById("fnameid").style.color="green";

    }
    if(lastname.length<2){
        document.getElementById("lnameid").innerHTML="Please enter your last name";
        document.getElementById("lnameid").style.color="red";
    }
    else{
        document.getElementById("lnameid").innerHTML="Accepted";
        document.getElementById("lnameid").style.color="green";

    }
    if(street.length<2){
        document.getElementById("streetid").innerHTML="Please enter your street's name";
        document.getElementById("streetid").style.color="red";
    }
    else{
        document.getElementById("streetid").innerHTML="Accepted";
        document.getElementById("streetid").style.color="green";

    }
}
//Checks age if the user is old enough according to that assign color and value//
function checkage(){
    var age = document.getElementById("age").value;
    if(parseInt(age)>5){
        document.getElementById("ageid").innerHTML="Valid";
        document.getElementById("ageid").style.color="green";
    }
    else{
        document.getElementById("ageid").innerHTML="Invalid";
        document.getElementById("ageid").style.color="red";

    }

}
//Check for phone number for validity//
function phonecheck(){
    var phone=document.getElementById("phone_number").value;
    var regex=/^\d{3}-\d{3}-\d{4}$/;
    if(regex.test(phone)){
        document.getElementById("phoneid").innerHTML="Valid";
        document.getElementById("phoneid").style.color="green";
    }
    else{
        document.getElementById("phoneid").innerHTML="invalid";
        document.getElementById("phoneid").style.color="red";
    }
}
function pincheck()//checking pin number//
{
    var pin=document.getElementById("pin").value;
    if(parseInt(pin.length)==6){
        document.getElementById("pinid").innerHTML="Valid";
        document.getElementById("pinid").style.color="green";

    }
    else{
        document.getElementById("pinid").innerHTML="InValid";
        document.getElementById("pinid").style.color="red";
    }
}
//checking password//
function passcheck(){
    var pass=document.getElementById("password1").value;
    if(pass.length>=5 && pass.length<=10){
        document.getElementById("passid").innerHTML="Valid";
        document.getElementById("passid").style.color="green";
        
    }
    else{
        document.getElementById("passid").innerHTML="Invalid";
        document.getElementById("passid").style.color="red";

    }
}
function print(){
    var input=document.getElementById("myslider").value;
    document.getElementById("rangeid").innerHTML=input;
}